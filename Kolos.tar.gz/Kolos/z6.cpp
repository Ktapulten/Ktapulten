#include <iostream>
#include <cmath>
using namespace std;
int* stworz(const unsigned n){
	int*t=new int[n]();
	return t;
}
void wypelnij(int *t,const unsigned n,const int p){
	double pierwiastek = sqrt(p);
	cout << pierwiastek << endl;
	t[0]=p;
	for(unsigned int i=1;i<n;i++){
		t[i] = t[i-1] + pierwiastek;
	}
}
void wypisz(int *t,const unsigned n){
	for(unsigned int i=0;i<n;i++){
		cout << t[i] << " ";
	}
	cout << endl;
}
void przesun(int *t,const unsigned n){
	int tmp=t[n-1];
	int tmp1=t[0];
	for(unsigned int i=0;i<n-1;i++){
		t[i]=t[i+1];
	}
	t[0]=tmp;
	t[n-1]=tmp1;
}
void usun(int *t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
int main(int argc,char*argv[]){
	if(argc<3){
		cout << "Podczas uruchamiania programu musisz podac dlugosc tablicy oraz liczbe p" << endl;
		return 1;
	}
	unsigned n = atoi(argv[1]);
	int p = atoi(argv[2]);
	int*t=stworz(n);
	wypelnij(t,n,p);
	wypisz(t,n);
	przesun(t,n);
	wypisz(t,n);
	usun(t);
	return 0;
}
