#include <iostream>
using namespace std;
int *stworz(const unsigned n){
	int*t=new int[n]();
	return t;
}
void wypisz(int *t,const unsigned n){
	for(unsigned int i=0;i<n;i++){
		cout << t[i] << " ";
	}
	cout << endl;
}
void wypelnij(int*t,const unsigned n){
	for(unsigned int i=n;i>0;i--){
		if(i>=(n/2)){
			t[i]=i;
		}
		else{
			t[i]=i*i;
		}
	}
}
void zmien(int*t,const unsigned n,const int p){
	for(unsigned int i=0;i<n;i++){
		if(t[i]%2==0){
			t[i]+=p;
		}
		else{
			t[i]-=p;
		}
	}
}
void usun(int *t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
int main(int argc,char*argv[]){
	if(argc<3){
		cout << "Musisz podac rozmiar tablicy oraz liczbe do funkcji zmien" << endl;
		return 1;
	}
	else{
		unsigned int n = atoi(argv[1]);
		int p = atoi(argv[2]);
		int*t=stworz(n);
		wypisz(t,n);
		wypelnij(t,n);
		wypisz(t,n);
		zmien(t,n,p);
		wypisz(t,n);
		usun(t);
		return 0;	
	}
}
