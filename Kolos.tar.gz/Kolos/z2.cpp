#include <iostream>
using namespace std;
int* stworz_tablice(int n){
	int* t= new int[n]();
	return t;
}
void wypisz_tablice(int *t,int n){
	for(int i=0;i<n;i++){
		cout << t[i] << " "; 
	}
	cout << endl;
}
void wypelnij(int *t,int n){
	for(int i=0;i<n;i++){
		t[i] = i;
	}
}	
void usun(int *t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
void liniowe_przeszukiwanie(int *t,int n){
	int max=0;
	for(int i=0;i<n;i++){
		if(t[i]>max){
			max=t[i];
		}
	}
	cout << "Liczba maks: " << max << endl;
}
void pozycja_maks(int *t,int n){
	int max=0;
	int x=0;
	for(int i=0;i<n;i++){
		if(t[i]>max){
			max=t[i];
		}
		x=i;
	}
	cout << "Pozycja na ktorej znajduje sie liczba maksymanla: " << x << endl;
}
int main(int argc,char *argv[]){
	if(argc<2){
		cout << "Musisz podac dlugosc tablicy w lini uruchomienia programu" << endl;
	}	
	int n = atoi(argv[1]);
	int* t= stworz_tablice(n);
	wypisz_tablice(t,n);
	wypelnij(t,n);
	wypisz_tablice(t,n);
	liniowe_przeszukiwanie(t,n);
	pozycja_maks(t,n);
	usun(t);
	return 0;
}
