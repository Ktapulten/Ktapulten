#include <iostream>
using namespace std;
void wypisz(int n){
	int i=0;
	cout << "Petla while" << endl;
	while(i<n){
		cout <<"Mateusz Kapitula" << " " ;
		i++;
	}
	cout << endl;
	i=0;
	cout << "Petla do while" << endl;
	do{
		cout <<"Mateusz Kapitula" << " ";
		i++;
	}while(i<n);
	cout << endl;
	cout << "Petla for" << endl;
	for(i=0;i<n;i++){
		cout <<"Mateusz Kapitula" << " ";
	}
}

int main(){
	int n;
	cout << "Ile razy chcesz zeby petla wypisala twoje imie?" << endl;
	cin >> n;
	wypisz(n);
	return 0;
}
