#include <iostream>
using namespace std;
int* stworz_tablice(const unsigned int n){
	int* t=new int[n]();
	return t;
}
void wypisz(int *t,const unsigned int n){
	for(unsigned int i=0;i<n;i++){
		cout << t[i] << " ";
	}
	cout << endl;
}
void wypelnij(int *t,const unsigned int n){
	t[2]=0;
	t[3]=1;
	for(unsigned int i=4;i<n;i++){
		int fib=t[i-1]+t[i-2];
		t[i]=fib;
	}
}
void suma_fib(int *t,const unsigned int n){
	int suma=0;
	for(unsigned int i=0;i<n;i++){
		suma+=t[i];
	}
	cout << "Suma fibonacciego to: "<< suma << endl;
}
void liczba_fib(int *t,const unsigned int n){
	unsigned int licznik =0;
	for(unsigned int i=0;i<n;i++){
		if(t[i]%2==0){
			licznik ++;
		}
	}
	cout << "Liczba nieparzystych wyrazow w tej tablicy: " << licznik << endl;
}
void usun(int *t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
int main(int argc,char *argv[]){
	if(argc<2){
		cout << "Musisz podac dlugosc tablicy w lini uruchomienia programu." << endl;
	}
	unsigned n = atoi(argv[1]);
	int* t=stworz_tablice(n);
	wypisz(t,n);
	wypelnij(t,n);
	wypisz(t,n);
	suma_fib(t,n);
	liczba_fib(t,n);
	usun(t);
	return 0;
}
