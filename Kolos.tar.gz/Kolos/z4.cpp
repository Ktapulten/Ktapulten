#include <iostream>
using namespace std;
int *stworz(const unsigned n){
	int *t=new int[n]();
	return t;
}
void wypelnij(int *t,const unsigned n){
	t[2]=0;
	t[3]=1;
	int fib;
	for(unsigned int i=4;i<n;i++){
		fib=t[i-1]+t[i-2];
		t[i]=fib;
	}
}
void wypisz(int *t,const unsigned n){
	for(unsigned int i=0;i<n;i++){
		cout << t[i] << " ";
	}
	cout << endl;
}
double srednia(int *t,const unsigned n){
	double licznik=0;
	double suma=0;
	for(unsigned int i=0;i<n;i++){
		suma+=t[i];
		licznik++;
	}
	return suma/licznik;
}
double srednia_parz(int *t,const unsigned n){
        double licznik=0;
        double suma=0;
        for(unsigned int i=0;i<n;i++){
		if(t[i]%2==0){
                suma+=t[i];
                licznik++;
		}
        }
        return suma/licznik;
}
double srednia_podz(int *t,const unsigned n){
        double licznik=0;
        double suma=0;
        for(unsigned int i=0;i<n;i++){
		if(t[i]%3==0){
                suma+=t[i];
                licznik++;
		}
        }
        return suma/licznik;
}

void usun(int*t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
int main(int argc,char*argv[]){
	if(argc<2){
		cout << "Musisz podac rozmiar tablicy" << endl;
		return 1;
	}
	else{
		unsigned int n = atoi(argv[1]);
		int *t=stworz(n);
		wypelnij(t,n);
		wypisz(t,n);
		cout << "Srednia artmetyczna to: " << srednia(t,n) << endl;
		cout << "Srednia parz to: " << srednia_parz(t,n) << endl;
		cout << "Srednia podz to: " << srednia_podz(t,n) << endl;
		usun(t);
		return 0;
	}
}
