#include <iostream>
#include <cstring>
#include <string>
using namespace std;
void szyfruj(char *zdanie,int bias){
	int n = strlen(zdanie);
	for(int i=0;i<n;i++){
		char tmp = zdanie[i];
		if(isalpha(tmp)){
			char baza = isupper(tmp) ? 'A':'a';
			tmp = (tmp-baza-bias) % 26 + baza;
		}
		zdanie[i]=tmp;
	}
}
void rozszyfruj(char *zdanie,int bias){
	szyfruj(zdanie,-bias);
}
int main(int argc,char *argv[]){
	char *zdanie = argv[1];
	int bias = stoi(argv[2]);
	cout << "Orginalna wiadomosc: " << zdanie << endl;
	szyfruj(zdanie,bias);
	cout << "Zaszyfrowana wiadomosc: " << zdanie << endl;
	rozszyfruj(zdanie,bias);
	cout << "Rozszyfrowana wiadomosc: " << zdanie << endl;
	return 0;
}
