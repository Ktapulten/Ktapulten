#include <iostream>
#include <string>
using namespace std;
//pomocnicza zmienia znak na ascii
int char_ascii(char c){
	
}

string rozszyfruj( ,char klucz){

}
int main(int argc,char**argv){
	if(argc<3){
		cout << "Nie podano tekstu do zaszyfrowania lub klucza" << endl;
		return 1;
	}
	string zdanie = argv[1];
	char klucz = argv[2];

	return 0;
}
