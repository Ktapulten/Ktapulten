#include <iostream>
#include <cstring>
using namespace std;

bool palindrom(const char*str){
	int n = strlen(str);
	for(int i=0;i<n/2;i++){
		if(str[i] != str[n-i-1]){
			return false;
		}
	}
	return true;
}
int main(int argc,char *argv[]){
	const char *input = argv[1];
	bool wynik = palindrom(input);
	if(wynik == true){
		cout << "Podany wyraz: " << input << " jest palindromem" << endl;
	}
	else{
		cout << "Podany wyraz: " << input << " nie jest palindromem" << endl;
	}
	return 0;
}
