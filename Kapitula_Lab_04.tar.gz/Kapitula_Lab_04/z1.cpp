#include <iostream>
#include <cstring>
using namespace std;
char* wstaw(const char* zrodlo,char symbol){
	int n = strlen(zrodlo) + 1 + strlen(zrodlo)/3;
	char* cel = new char[n+1];
	int i=0;
	int j=0;
	for(;zrodlo[j];++i)
		if(i%4==0)
			cel[i]=symbol;		
		else{
		cel[i]=zrodlo[j];
		j++;
		}
	cel[j]=0;
	return cel;
}
void wstaw(char* cel,const char* zrodlo,char symbol){
	int n = strlen(zrodlo);
	int j=0;
	int i=0;
	for(;i<n;++i)
		if(i%4==0)
			cel[i]=symbol;
		else{
			cel[i]=zrodlo[j];
			j++;
		}
	cel[j]=0;
}
void wstaw1(char*& cel,const char* zrodlo,char symbol){
	int n= strlen(zrodlo + 1 +strlen(zrodlo)/3);
	cel = new char[n +1];
	int j=0;
	int i=0;
	for(;i<n;i++){
		if(i%4==0)
			cel[i]=symbol;
		else{
			cel[i]=zrodlo[j];
			j++;
		}
	}
	cel[j]=0;
}
int szukaj(const char* zrodlo,char symbol){
	int n = strlen(zrodlo);
	int licznik = 0;
	for(int i =0;i<n;i++){
		if(zrodlo[i]==symbol){
			licznik++;
		}
	}
	return licznik;
}
char* kopiuj(char* zrodlo){
	int n= strlen(zrodlo);
	char* cel = new char[n+1];
	int i =0;
	for(;i<n;i++){
		cel[i] = toupper(zrodlo[i]);
	}
	cel[i] = 0;
	return cel;
}

void usun(const char*t){
	if(t){
		delete[] t;
		t=nullptr;
	}
}
int main(int argc,char* argv[]){
	if(argc!=3){
		cout << "Uzycie: " << argv[0] << " napisz symbol" << endl;
		return 1;
	}
	char* a = wstaw(argv[1],argv[2][0]);
	int n = strlen(argv[1]+ 1 + strlen(argv[1]) / 3);
	char* b = new char[n+1];
	char* c = nullptr;
	wstaw(b,argv[1],argv[2][0]);
	wstaw1(c,argv[1],argv[2][0]);
	cout << a << endl;
	cout << szukaj(a, 's') << endl;
	usun(a);
	a = kopiuj(argv[1]);
	cout << a << endl;
	usun(a);
	usun(b);
	usun(c);
	a=nullptr;
	b=nullptr;
	c=nullptr;
	return 0;
}
