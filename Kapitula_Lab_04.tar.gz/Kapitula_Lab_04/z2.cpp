#include <iostream>
#include <cstring>
using namespace std;
int liczba_wyrazow(char* wyraz){
	int licznik=0;
	for(int i=0;i<static_cast<int>(strlen(wyraz));i++){
		if(wyraz[i] ==' '){
			licznik++;
		}
	}
	return licznik + 1;
}
int main(int argc,char* argv[]){
	if(argc>1){
		char* wyraz=argv[1];
		cout << "Liczba wyrazow: " << liczba_wyrazow(wyraz) << endl;
	}
	else{
		cout << "Musisz przekazac jakies zdanie do funkcji aby policzyc ilosc wyrazow" << endl;
	}
	return 0;
}
