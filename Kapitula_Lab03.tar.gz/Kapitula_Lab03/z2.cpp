#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void losowanie(int *T,int a, int b,const int N){
        srand(time(NULL));
        for(int i=0;i<N;i++){
                T[i]= rand() % (b-a+1) + a;
        }
}
void liczby(int *T,const int N){
        cout << "Podaj liczby z zakresu 1-49" << endl;
        for(int i=0;i<N;i++){
                cin>>T[i];
        }
}
int liczby_dobre(int *wygrane,int *wybrane,const int N){
        int wygranee=0;
        for(int i=0;i<N;i++){
                for(int j=0;j<N;j++){
                        if(wygrane[i]==wybrane[j]){
                                wygranee++;
                        }
                }
        }
        return wygranee;
}
void totalizator(int wygrane){
        switch(wygrane){
                case 0:
                        cout << "Nic nie wygrales , zero trafionych liczb" << endl;
                        break;
                case 1:
                        cout << "Gratulacje, trafiles jedna liczbe" << endl;
                        break;
                case 2:
                        cout << "Gratulacje, trafiles dwie liczby" << endl;
                        break;
                case 3:
                        cout << "Gratulacje, trafiles trzy liczby" << endl;
                        break;
                case 4:
                        cout << "Gratulacje, trafiles cztery liczby" << endl;
                        break;
                case 5:
                        cout << "Gratulacje, trafiles piec liczb" << endl;
                        break;
                default:
                        cout << "Blad, liczba trafien poza zakresem" << endl;
                        break;
        }
}
int main(){
        const int N=6;
        int wygrane[N];
        int wybrane[N];
        int a,b;
        cout << "Podaj najpierw dolny i gorny (w tej kolejnosci) zakres losowania";
        cin>>a>>b;
        losowanie(wygrane,N,a,b);
        liczby(wybrane,N);
        cout << "Wylosowane liczby to: ";
        for(int i=0;i<N;i++){
                cout << wygrane[i] << " ";
        }
        cout << endl;

        int tmp = liczby_dobre(wygrane,wybrane,N);
        cout << "Liczba trafionych liczb: " << tmp << endl;
        totalizator(tmp);
        return 0;
}

