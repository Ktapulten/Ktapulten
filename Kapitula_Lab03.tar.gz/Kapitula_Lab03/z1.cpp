#include <iostream>
#include <ctime>
#include <cmath>
#include <cstdlib>
using namespace std;
void wypisz(int **t,const unsigned n,const unsigned m){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<n;j++){
                        cout << t[i][j] << " ";
                }
                cout << endl;
        }
        cout << endl;
}
int** utworz(const unsigned int n,const unsigned int m){
        int **t=new int*[n];
        for(unsigned int i=0;i<n;i++){
                t[i]=new int[m];
        }
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t[i][j]=0;
                        }
        }
        return t;
}
void utworz(int **& t,const unsigned n,const unsigned m){
        t = new int*[n];
        for(unsigned int i=0;i<n;i++){
                t[i]=new int[m];
        }
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t[i][j]=0;
                }
        }
}
void utworz1(int **t,const unsigned n,const unsigned m){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t[i][j]=0;
                }
        }
}
int* utworz1(const unsigned m){
        int* t=new int[m];
        for(unsigned int i=0;i<m;i++){
                t[i]=0;
        }
        return t;
}
void usun(int** t,const unsigned n){
        if(t){
                unsigned int i=0;
                for(unsigned int i;i<n;i++){
                        delete[]t[i];
                }
                delete[] t;
                t[i]=nullptr;
        }
        delete[]t;
        t=nullptr;
}
void wypelnij(int** t,const unsigned n,const unsigned m,const int min,const int max){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t[i][j]=rand()%(max-min+1) + min;
                }
        }
}
void suma(int **t,int** t2,int** t3,const unsigned n,const unsigned m){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t3[i][j]=t[i][j]+t2[i][j];
                }
        }
}
void roznica(int **t,int **t2,int** t3,const unsigned n,const unsigned m){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t3[i][j]=t[i][j]-t2[i][j];
                }
        }
}
void iloczyn(int **t,int **t2,int **t3,const unsigned n,const unsigned m){
        for(unsigned i=0;i<n;i++){
                t3[i]=0;
                for(unsigned j=0;j<m;j++){
                        t3[i] = t3[i] + t[i][j] * t2[i][j];
                }
        }
}
void transponowanie(int**t,int**t2,const unsigned n,const unsigned m){
        for(unsigned int i=0;i<n;i++){
                for(unsigned int j=0;j<m;j++){
                        t2[j][i]=t[i][j];
                }
        }
}
void tabliczka(const unsigned n,const unsigned m){
        for(unsigned int i=1;i<=n;i++){
                for(unsigned int j=1;j<=m;j++){
                        cout << i*j << " ";
                }
        }
        cout << endl;
}
int main(){
        srand(time(NULL));
        unsigned int n=0,m=0;
        cout << "Podaj liczbe n,m: " << endl;
        cin>>n>>m;
        int**t=utworz(n,m);
        int**t2=utworz(n,m);
        int**t3=utworz(n,m);
        int min,max;
        cout << "Podaj przedzial liczb losowych (min,max): " << endl;
        cin >>min>>max;
        wypelnij(t,n,m,min,max);
        wypelnij(t2,n,m,min,max);
        wypelnij(t3,n,m,min,max);
        cout<< "Wypelniona tablica dwuwymiarowa : " << endl; 
        wypisz(t,n,m);
        suma(t,t2,t3,n,m);
        roznica(t,t2,t3,n,m);
        iloczyn(t,t2,t3,n,m);
        transponowanie(t,t2,n,m);
        tabliczka(n,m);
        usun(t,n);
        usun(t2,n);
        usun(t3,n);
        return 0;
}
