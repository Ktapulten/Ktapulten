#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

const int lottoKolumny = 6;
const int lottoPlusKolumny = 6;
const int multiMultiKolumny = 10;

bool czyIstnieje(int num, int* t, int size) {
    for (int i = 0; i < size; i++) {
        if (t[i] == num) {
            return true;
        }
    }
    return false;
}

void pobierzLiczby(int** t, int liczbaWierszy, int liczbaKolumn) {
    for (int i = 0; i < liczbaWierszy; i++) {
        cout << "Kupon " << i + 1 << ":" << endl;
        for (int j = 0; j < liczbaKolumn; j++) {
            int num;
            do {
                cout << "Podaj liczbe " << j + 1 << ": ";
                cin >> num;
            } while (num < 1 || num > (liczbaKolumn == 10 ? 80 : 49) || czyIstnieje(num, t[i], j));
            t[i][j] = num;
        }
    }
}

void losowanieLiczb(int* t, int size) {
    for (int i = 0; i < size; i++) {
        int num;
        do {
            num = rand() % (size == 10 ? 80 : 49) + 1;
        } while (czyIstnieje(num, t, i));
        t[i] = num;
    }
}

void wyswietl(int** t, int liczbaWierszy, int liczbaKolumn) {
    for (int i = 0; i < liczbaWierszy; i++) {
        cout << "Kupon " << i + 1 << ": ";
        for (int j = 0; j < liczbaKolumn; j++) {
            cout << t[i][j] << " ";
        }
        cout << endl;
    }
}

int licznikTrafien(int* t1, int* t2, int size) {
    int trafienia = 0;
    for (int i = 0; i < size; i++) {
        if (czyIstnieje(t1[i], t2, size)) {
            trafienia++;
        }
    }
    return trafienia;
}

void wygraneLiczby(int* liczbyWygrane, int** t, int liczbaWierszy, int liczbaKolumn) {
    for (int i = 0; i < liczbaWierszy; i++) {
        int liczbyTrafione = licznikTrafien(liczbyWygrane, t[i], liczbaKolumn);
        cout << "Kupon " << i + 1 << " ma " << liczbyTrafione << " trafien." << endl;
    }
}

int main() {
    srand(time(NULL));

    int num_lotto_rows, num_lottoplus_rows, num_multimulti_rows;
    cout << "Podaj liczbe kuponow Lotto: ";
    cin >> num_lotto_rows;
    cout << "Podaj liczbe kuponow Lotto Plus: ";
    cin >> num_lottoplus_rows;
    cout << "Podaj liczbe kuponow Multi Multi: ";
    cin >> num_multimulti_rows;

    int** lotto = new int*[num_lotto_rows];
    for (int i = 0; i < num_lotto_rows; i++) {
        lotto[i] = new int[lottoKolumny];
    }
    int** lottoplus = new int*[num_lottoplus_rows];
    for (int i = 0; i < num_lottoplus_rows; i++) {
        lottoplus[i] = new int[lottoPlusKolumny];
	}
    int** multimulti = new int*[num_multimulti_rows];
    for (int i = 0; i < num_multimulti_rows; i++) {
    multimulti[i] = new int[multiMultiKolumny];
    }

    cout << "Podaj liczby na kuponach Lotto:" << endl;
    pobierzLiczby(lotto, num_lotto_rows, lottoKolumny);
    cout << endl;

    cout << "Wylosowane liczby Lotto: ";
    int* lotto_liczbyWygrane = new int[lottoKolumny];
    losowanieLiczb(lotto_liczbyWygrane, lottoKolumny);
    for (int i = 0; i < lottoKolumny; i++) {
    cout << lotto_liczbyWygrane[i] << " ";
    }
    cout << endl;
    wygraneLiczby(lotto_liczbyWygrane, lotto, num_lotto_rows, lottoKolumny);

    cout << endl << "Podaj liczby na kuponach Lotto Plus:" << endl;
    pobierzLiczby(lottoplus, num_lottoplus_rows, lottoPlusKolumny);
    cout << endl;

    cout << "Wylosowane liczby Lotto Plus: ";
    int* lottoplus_liczbyWygrane = new int[lottoPlusKolumny];
    losowanieLiczb(lottoplus_liczbyWygrane, lottoPlusKolumny);
    for (int i = 0; i < lottoPlusKolumny; i++) {
    cout << lottoplus_liczbyWygrane[i] << " ";
    }
    cout << endl;
    wygraneLiczby(lottoplus_liczbyWygrane, lottoplus, num_lottoplus_rows, lottoPlusKolumny);

    cout << endl << "Podaj liczby na kuponach Multi Multi:" << endl;
    pobierzLiczby(multimulti, num_multimulti_rows, multiMultiKolumny);
    cout << endl;

    cout << "Wylosowane liczby Multi Multi: ";
    int* multimulti_liczbyWygrane = new int[multiMultiKolumny];
    losowanieLiczb(multimulti_liczbyWygrane, multiMultiKolumny);
    for (int i = 0; i < multiMultiKolumny; i++) {
    cout << multimulti_liczbyWygrane[i] << " ";
    }
    cout << endl;
    wygraneLiczby(multimulti_liczbyWygrane, multimulti, num_multimulti_rows, multiMultiKolumny);

    cout<<"Liczby wprowadzone przez uzytkownika: " << endl;
    wyswietl(lotto,num_lotto_rows,lottoKolumny);
    wyswietl(lottoplus,num_lottoplus_rows,lottoPlusKolumny);
    wyswietl(multimulti,num_multimulti_rows,multiMultiKolumny);
    cout <<"Wyniki losowania: "<<endl;
    wygraneLiczby(lotto_liczbyWygrane, lotto, num_lotto_rows, lottoKolumny);
    wygraneLiczby(lottoplus_liczbyWygrane, lottoplus, num_lottoplus_rows, lottoPlusKolumny);
    wygraneLiczby(multimulti_liczbyWygrane, multimulti, num_multimulti_rows, multiMultiKolumny);
//Funckja usun jest work in progress a nie wywala memory leakow i sie kompiluje poki co
    for (int i = 0; i < num_lotto_rows; i++) {
    delete[] lotto[i];
    }
    delete[] lotto;
    lotto= nullptr;
    for (int i = 0; i < num_lottoplus_rows; i++) {
    delete[] lottoplus[i];
    }
    delete[] lottoplus;
    lottoplus = nullptr;
    for (int i = 0; i < num_multimulti_rows; i++) {
    delete[] multimulti[i];
    }
    delete[] multimulti;
    multimulti = nullptr;
    delete[] lotto_liczbyWygrane;
    delete[] lottoplus_liczbyWygrane;
    delete[] multimulti_liczbyWygrane;

    return 0;
}
