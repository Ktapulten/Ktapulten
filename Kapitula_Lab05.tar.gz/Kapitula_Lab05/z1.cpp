#include <iostream>
#include <string>
using namespace std;

void kopiuj(const string src, char*& dest) {
    dest = new char[src.length()+1];
    for(size_t i=0; i<=src.length(); i++) {
        dest[i] = src[i];
    }
}

int porownaj(const string s1, const string s2) {
    if(s1<s2) {
        return -1;
    } else if(s1>s2) {
        return 1;
    } else {
        return 0;
    }
}

string wstaw(const string src, const char s, size_t p) {
    string result = src;
    if(p <= src.length()) {
        result.insert(p, 1, s);
    }
    return result;
}

string wstaw1(const string src, const char s, size_t p) {
    string result = src;
    if(p <= src.length()) {
        result.insert(p, 1, s);
    }
    return result;
}

string wytnij(const string src, size_t n) {
    if(n <= src.length()) {
        return src.substr(0, n);
    } else {
        return src;
    }
}

int szukaj(const string src, const char s) {
    size_t poz = src.find(s);
    if(poz != string::npos) {
        return static_cast<int>(poz);
    } else {
        return -1;
    }
}

int szukaj(const string src, const char* s) {
    size_t poz = src.find(s);
    if(poz != string::npos) {
        return static_cast<int>(poz);
    } else {
        return -1;
    }
}

void usun(char*& t) {
    if(t) {
        delete[] t;
        t = nullptr;
    }
}

int main(int argc, char **argv) {
    char* dest = nullptr;
    if(argc < 5) {
        cout << "Za malo podanych argumentow podczas uruchamiania programu" << endl;
        return 1;
    }
    string src = argv[1];
    char s = argv[2][0];
    const size_t p = atoi(argv[3]);
    const size_t n = atoi(argv[4]);
    //kopiowanie
    kopiuj(src, dest);
    cout << "Kopiuj: " << dest << endl;
    usun(dest);
    //test przypisania
    cout << "Napis podany: " << src << endl;
    string result = src;
    cout <<"Napis przypisany: "<< result << endl;
    //wstawianie z pojedynczym znakiem
    cout << "Zdanie przed wstawieniem: " << src << endl;
    cout << "Zdanie po wstawieniu: " << wstaw(src, s, p) << endl;  
    //wstawianie z napisem
    cout << "Zdanie przed wstawieniem: " << src << endl;
    string result2 = wstaw(src, s, p);
    cout << "Zdanie po wstawieniu" << result2 << endl;
    //wytnij
    cout << "Przed wycieciem: " << src << endl;
    string result3 = wytnij(src, n);
    cout << "Po wycieciu: " << result3 << endl;
    //szukaj
    int result4 = szukaj(src, s); 
    cout << "Wynik szukania pojedynczego znaku: " << result4 << endl;
    int result5 = szukaj(src, argv[2]);
    cout << "Wynik szukania ciagu znakow: " << result5 << endl;
    //porownaj
    string s1 = "Test";
    string s2= "Test";
    int result6 = porownaj(s1,s2);
    cout << "Wynik porownania: " << result6 << endl;
    return 0;
}
