#include <iostream>
#include <string>
using namespace std;

int liczba_wyrazow(string tekst){
	int licznik = 0;
	bool czy_wyraz = false;
	for(long unsigned int i=0;i<tekst.length();i++){
		char znak = tekst[i];
		if(isalpha(znak)&&!czy_wyraz){
			licznik++;
			czy_wyraz = true;
		}
		else if(isspace(znak)|| ispunct(znak)){
			czy_wyraz = false;
		}
	}
	return licznik;
}

int main(int argc,char **argv){
	if(argc<2){
		cout << "Za mala liczba argumentow" << endl;
	}
	string tekst = argv[1];
	int liczba_wyrazoww = liczba_wyrazow(tekst);
	cout << "Liczba wyrazow: " << liczba_wyrazoww << endl;
	return 0;
}

