#include <iostream>
#include <string>

using namespace std;

string szyfruj(string wiadomosc, int klucz) {
    string zaszyfrowana_wiadomosc = "";
    for (long unsigned int i = 0; i < wiadomosc.length(); i++) {
        char litera = toupper(wiadomosc[i]);
        if (litera >= 'A' && litera <= 'Z') {
            litera = ((litera - 'A' + klucz) % 26) + 'A';
        }
        zaszyfrowana_wiadomosc += litera;
    }
    return zaszyfrowana_wiadomosc;
}

string deszyfruj(string zaszyfrowana_wiadomosc, int klucz) {
    string odszyfrowana_wiadomosc = "";
    for (long unsigned int i = 0; i < zaszyfrowana_wiadomosc.length(); i++) {
        char litera = toupper(zaszyfrowana_wiadomosc[i]);
        if (litera >= 'A' && litera <= 'Z') {
            litera = ((litera - 'A' + 26 - klucz) % 26) + 'A';
        }
        odszyfrowana_wiadomosc += litera;
    }
    return odszyfrowana_wiadomosc;
}

int main() {
    string wiadomosc = "To jest testowa wiadomosc";
    int klucz = 3;

    string zaszyfrowana_wiadomosc = szyfruj(wiadomosc, klucz);
    cout << "Zaszyfrowana wiadomosc: " << zaszyfrowana_wiadomosc << endl;

    string odszyfrowana_wiadomosc = deszyfruj(zaszyfrowana_wiadomosc, klucz);
    cout << "Odszyfrowana wiadomosc: " << odszyfrowana_wiadomosc << endl;

    return 0;
}

