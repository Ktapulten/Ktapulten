#include <iostream>
#include <string>
using namespace std;

string szyfruj(string wiadomosc, char klucz) {
    string wynik = "";
    for (int i = 0; i < wiadomosc.length(); i++) {
        int xorValue = wiadomosc[i] ^ klucz;
        wynik += char(xorValue);
    }
    return wynik;
}

string odszyfruj(string zaszyfrowanaWiadomosc, char klucz) {
    string wynik = "";
    for (int i = 0; i < zaszyfrowanaWiadomosc.length(); i++) {
        int xorValue = zaszyfrowanaWiadomosc[i] ^ klucz;
        wynik += char(xorValue);
    }
    return wynik;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        cout << "Uzycie: " << argv[0] << " wiadomosc klucz" << endl;
        return 1;
    }

    string wiadomosc = argv[1];
    char klucz = argv[2][0];

    cout << "Wiadomosc: " << wiadomosc << endl;
    cout << "Klucz: " << klucz << endl;

    string zaszyfrowanaWiadomosc = szyfruj(wiadomosc, klucz);
    cout << "Zaszyfrowana wiadomosc: " << zaszyfrowanaWiadomosc << endl;

    string odszyfrowanaWiadomosc = odszyfruj(zaszyfrowanaWiadomosc, klucz);
    cout << "Odszyfrowana wiadomosc: " << odszyfrowanaWiadomosc << endl;

    return 0;
}

