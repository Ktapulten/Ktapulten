#include <iostream>
#include <string>

using namespace std;

bool palindrom(const string& zdanie)
{
    int i = 0;
    int j = zdanie.length() - 1;

    while(i < j)
    {
        while(i < j && !isalnum(zdanie[i]))
        {
            i++;
        }
        while(i < j && !isalnum(zdanie[j]))
        {
            j--;
        }

        if(tolower(zdanie[i]) != tolower(zdanie[j]))
        {
            return false;
        }

        i++;
        j--;
    }

    return true;
}

int main(int argc, char* argv[])
{
    if(argc < 2)
    {
        cout << "Zla liczba argumentow: " << endl;
        return 1;
    }

    string zdanie = argv[1];

    if(palindrom(zdanie))
    {
        cout << "Zdanie jest palindromem" << endl;
    }
    else
    {
        cout << "Zdanie nie jest palindromem" << endl;
    }

    return 0;
}

