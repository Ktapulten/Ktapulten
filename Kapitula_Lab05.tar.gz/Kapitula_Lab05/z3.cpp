#include <iostream>
#include <string>

using namespace std;

const int MAX_EMAILS = 100; // maksymalna liczba adresów email

void readEmails(string* emails, int& email_count) {
    string input; // zmienna do przechowywania danych osobowych

    // Odczytanie danych osobowych ze strumienia standardowego wejścia
    while (true) {
        cout << "Podaj imię, nazwisko, pseudonim, rok urodzenia i adres e-mail (lub END, aby zakończyć): ";
        getline(cin, input);

        if (input == "END" || input == "end") {
            break;
        }

        // Wyselekcjonowanie adresów email
        size_t at_pos = input.find('@');
        if (at_pos != string::npos) {
            emails[email_count] = input.substr(at_pos);
            email_count++;
        }

        // Przerwanie pętli, jeśli osiągnięto maksymalną liczbę adresów email
        if (email_count >= MAX_EMAILS) {
            break;
        }
    }
}

void printEmails(string* emails, int email_count) {
    // Zapisanie adresów email do strumienia standardowego wyjścia
    for (int i = 0; i < email_count; i++) {
        cout << emails[i] << "; ";
    }
}

int main() {
    string* emails = new string[MAX_EMAILS]; // dynamiczna tablica do przechowywania adresów email
    int email_count = 0; // licznik adresów email

    readEmails(emails, email_count);

    printEmails(emails, email_count);

    delete[] emails; // zwolnienie pamięci
    return 0;
}

