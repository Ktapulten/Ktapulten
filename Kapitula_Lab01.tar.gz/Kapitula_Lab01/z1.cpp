#include <iostream>

using namespace std;

int main(){
	unsigned int n=0;
	cout << "Podaj liczbe wyswielten, wieksza od 0" << endl;
	cin >> n;

	unsigned int i=0;
	do{
		cout <<"Mateusz Kapitula"<< endl;
		i++;
	}
	while(i<n);
	i=0;
	while(i<n){
		cout << "Mateusz Kapitula" << endl;
		i++;
	}
	for(i=0;i<n;i++){
		cout << "Mautesz Kapitula" << endl;

	}
	return 0;
}
