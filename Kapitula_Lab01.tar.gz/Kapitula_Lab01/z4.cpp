#include <iostream>

using namespace std;

void wypelnij(int *T,const unsigned N){
	T[2]=0;
	T[3]=1;
	for(unsigned int i=4;i<N;i++){
		T[i]=T[i-1]+T[i-2];
	}
}
void wypisz(int *T,const unsigned N){
	for(unsigned int i=0;i<N;i++){
		cout<<T[i]<<" ";
	}
}
float srednia(int *T,const unsigned N){
	unsigned int licznik = 0;
	unsigned int srednia = 0;
	for(unsigned int i=0;i<N;i++){
		srednia = srednia + T[i];
		licznik ++;
	}
	float wynik = srednia / licznik;
	return wynik;
}
float srednia_parz(int *T,const unsigned N){
        unsigned int licznik = 0;
        unsigned int srednia = 0;
        for(unsigned int i=0;i<N;i++){
                if(T[i]%2==0){
			srednia = srednia + T[i];
			licznik ++;
		}
        }
        float wynik = srednia / licznik;
        return wynik;
}
float srednia_podz(int *T,const unsigned N){
        unsigned int licznik = 0;
        unsigned int srednia = 0;
        for(unsigned int i=0;i<N;i++){
                if(T[i]%3==0){ 
                        srednia = srednia + T[i];
                        licznik ++;
                }
        }
        float wynik = srednia / licznik;
        return wynik;
}
int main(){
        unsigned int N;
        cout<<"Wpisz rozmiar tablicy"<<endl;
        cin>>N;

        int*T=new int[N];
        wypelnij(T,N);
        wypisz(T,N);
        srednia(T,N);
        srednia_parz(T,N);
	srednia_podz(T,N);
        delete[] T;
        T=nullptr;
	return 0;
}
