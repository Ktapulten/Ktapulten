#include <iostream>
#include <cmath>
using namespace std;

void wypelnij(int *T,const unsigned N,unsigned int pierwsza){
        T[0]=pierwsza;
	unsigned int pierwiastek=sqrt(pierwsza);
        for(unsigned int i=1;i<N;i++){
                T[i]= T[i-1] + pierwiastek;
        }
}
void wypisz(int *T,const unsigned N){
        for(unsigned int i=0;i<N;i++){
                cout<<T[i]<<" "<<endl;
        }
}
void przesun(int *T,const unsigned N){
        int Temp = T[N-1];
        for(unsigned int i= N-1;i>=0;--i){
                 T[i]=T[i-1];
        }
        T[0]=Temp;
}
int main(){
        unsigned int N;
        cout<<"Wpisz rozmiar tablicy"<<endl;
        cin>>N;
	unsigned int pierwsza;
	cout<<"Podaj liczbe"<<endl;
	cin>>pierwsza;
        int*T=new int[N];
        wypelnij(T,N,pierwsza);
        wypisz(T,N);
	przesun(T,N);
        delete[] T;
        T=nullptr;
        return 0;
}
