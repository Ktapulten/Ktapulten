#include <iostream>
#include <cmath>
using namespace std;
void sito(int *T,const unsigned N){
	for(unsigned int i=0;i<=N;i++){
		T[i]=1;
	}
	for(unsigned int i =2; i*i<=N;i++){
		if(T[i]==1){
			for(unsigned int j = i*i;j<=N; j+=i){
				T[j] = 0;
			}
		}
	}
}

int main(){
	unsigned int N;
	cout << "Podaj gorna granice przedzialu: " << endl;
	cin >> N;
	int *T=new int[N+1];
	sito(T,N);
	cout << "Liczby pierwsze w przedziale to: " << endl;
	for(unsigned int i = 2; i<=N;i++){
		if(T[i]==1){
			cout<< i << " ";
		}
	}
	delete[] T;
	T=nullptr;
	return 0;
}
