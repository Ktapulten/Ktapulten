#include <iostream>
using namespace std;
void wypelnij(int *T,const unsigned N){
	unsigned int polowa = N/2;
	for(unsigned int i=N;i>=0;--i){
		if(i<polowa){
			T[i]=i;
		}
		else{
			T[i]=i*i;
		}
	}
}
void wypisz(int*T,const unsigned N){
	for(unsigned int i=0;i<N;i++){
		cout<<T[i]<<" ";
	}
}
void zmien(int *T,const unsigned N,const unsigned liczba){
	for(unsigned int i=0;i<N;i++){
		if(T[i]%2==0){
			T[i]= T[i] + liczba;
		}
		else{
			T[i] =T[i] - liczba;
		}
	}
}
int main(){
        unsigned int N;
        cout<<"Wpisz rozmiar tablicy"<<endl;
        cin>>N;
	unsigned int liczba;
	cout<<"Podaj liczbe"<<endl;
	cin>>liczba;
        int*T=new int[N];
        wypelnij(T,N);
        wypisz(T,N);
        zmien(T,N,liczba);
        delete[] T;
        T=nullptr;
        return 0;
}
