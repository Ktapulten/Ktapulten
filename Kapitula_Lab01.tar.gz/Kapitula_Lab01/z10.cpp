#include <iostream>
using namespace std;

int Horner(int *T,const unsigned N,unsigned x){
	int wynik=T[N];
	for(unsigned int i = N-1;i>=0;i--){
		wynik= wynik * x + T[i];
	}
	return wynik;
}
int main(){
	unsigned int N;
	cout << "Podaj stopien wielomianu: " << endl ; 
	cin >> N;

	int *T = new int[N+1];
	cout << "Podaj wspolczynniki wielomianu od najwyzszej potegi: " << endl ;
	for(unsigned int i = N; i>=0;i--){
		cin >> T[i];
	}

	unsigned int x;
	cout << "Podaj x: " << endl;
	cin >> x;
	int wynik = Horner(T,N,x);
	cout << "Wartosc wielomianu dla x: "<< x << "wynosi: " << wynik << endl;
	delete[] T;
	T=nullptr;
	return 0;
}
