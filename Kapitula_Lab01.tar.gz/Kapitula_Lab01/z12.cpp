#include <iostream>
using namespace std;

int nwd(unsigned int a, unsigned int b){
	unsigned int temp;
	while(b!=0){
		temp=b;
		b=a%b;
		a=temp;
	}
	return a;
}

int main(){
	unsigned int a,b;
	cout << "Podaj dwie liczby: " << endl;
	cin >> a >> b;
	int wynik = nwd(a,b);
	cout << "Dla liczb: "<< a << " i " << b << " wynik to : " << wynik << endl;
	return 0;
}
