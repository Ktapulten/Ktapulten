#include <iostream>
using namespace std;
void wypelnij(int *T,const unsigned N){
	for(unsigned int i=0;i<N;i++){
		T[i]=i;
	}
}
void wypisz(int *T,const unsigned N){
	for(unsigned int i=0;i<N;i++){
		cout<<T[i]<<" ";
	}
}
void sortuj(int *T,const unsigned N){
	for(unsigned int i=0;i<N;i++){
		for(unsigned int j=1;j<N-i;j++){
			if(T[j-1]>T[j]){
				swap(T[j-1],T[j]);
			}
		}
	}
}
void binarnie(int *T,const unsigned N,int liczba){
	unsigned int l =0;
	unsigned int p =N-1;
	unsigned int sr;
	while(l<=p){
		sr = (l+p)/2;
		if(T[sr]==liczba){
			cout << "Liczba ktorej szukasz:" + sr << endl;
		}
		if(T[sr]>liczba){
			p = sr -1;
		}
		else{
			l = sr +1;
		}
	}

}
int main(){
        unsigned int N;
        cout<<"Wpisz rozmiar tablicy"<<endl;
        cin>>N;
	int liczba;
	cout<<"Podaj liczbe ktora chcesz znalezc"<<endl;
	cin>>liczba;
        int*T=new int[N];
        wypelnij(T,N);
        wypisz(T,N);
        sortuj(T,N);
	binarnie(T,N,liczba);
        delete[] T;
        T=nullptr;
        return 0;
}
