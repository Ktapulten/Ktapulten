#include <iostream>
#include <cmath>

using namespace std;

void pierwiastki(double a,double b,double c,double &x1, double &x2){
	double delta = b*b-4*a*c;
	if(delta>=0){
		x1 = (-b+sqrt(delta)) / (2*a);
		x2 = c/(a*x1);
	}
	else{
		cout << "Delta ujemna , brak miejsc zerowych" << endl;
	}
}

int main(){
	double a,b,c,x1,x2;
	cout << "Podaj liczby a,b,c" << endl;
	cin >> a >> b >> c;
	pierwiastki(a,b,c,x1,x2);
	cout << "Pierwiastki rownania to: " << x1 << " i " << x2 << endl;
	return 0;

}
