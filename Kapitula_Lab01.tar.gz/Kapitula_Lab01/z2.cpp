#include <iostream>

using namespace std;

void wypelnij(int *T,const unsigned N){
	for( unsigned int i =0;i<N;i++){
		T[i]=i+1;
	}	
}
void wypisz(int *T,const unsigned N){
        for( unsigned int i=0;i<N;i++){
                cout<< T[i] << " ";
        }
}
void maksymalna(int *T,const unsigned N){
        int max=T[0];
        for(unsigned int i=0;i<N;i++){
		if(max<T[i]){
			max=T[i];
		}
	}
	cout << max << endl;
}
void pozycja(int *T,const unsigned N){
        int max1=0;
	unsigned int x=0;
        for(unsigned int i=0;i<N;i++){
		if(max1<T[i]){
			max1=T[i];
		}
		x = i;
        }
	cout << x << endl;
}

int main(){
	unsigned int N;
	cout<<"Wpisz rozmiar tablicy"<<endl;
	cin>>N;

	int*T=new int[N];
	wypelnij(T,N);
	wypisz(T,N);
	maksymalna(T,N);
	pozycja(T,N);
	delete[] T;
	T=nullptr;
	return 0;
}
