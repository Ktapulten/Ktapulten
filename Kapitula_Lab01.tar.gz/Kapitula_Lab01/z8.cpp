#include <iostream>
#include <cmath>
using namespace std;

void pobierz(double &a, double &b, double&c){
	cout << "Podaj dlugosci bokow trojkata: "<< endl;
	cin >> a >> b >> c;
}

bool sprawdz(double a, double b, double c){
	if(a+b>c && a+c>b && b+c>a){
		return true;
	}
	else{
		return false;
	}
}

double pole(double a,double b, double c){
	double p = (a+b+c)/2;
	double s = sqrt(p*(p-a)*(p-b)*(p-c));
	return s;
}

int main(){
	double a,b,c;
	pobierz(a,b,c);
	if(sprawdz(a,b,c)){
		cout << "Podane boki trojkata moga tworzyc trojkat"<< endl;
		cout << "Pole trojkata wynosi: "<<pole(a,b,c)<< endl;
	}
	else{
		cout << "Podane boki trojkata nie moga tworzyc trojkata" << endl;
	}
	return 0;
}
