#include <iostream>
using namespace std;
int silnia_iter(int n){
	int wynik = 1;
	for(int i = 1; i<=n;i++){
		wynik = wynik * i;
	}
	return wynik;
}
int fib_iter(int n){
	if(n==0 || n == 1){
		return n;
	}
	else{
		int a=0;
		int b=1;
		int c;
		for(int i=2;i<=n;i++){
			c = a+b;
			a = b;
			b = c;
		}
	return b;
	}
}
int pot_naturalne_iter(int a, int n){
	int wynik=1;
	for(int i=1; i<=n; i++){
		wynik = wynik *a;
	}
	return wynik;
}

int silnia_rek(int n){
	if(n==0){
		return 1;
	}
	else{
		return n * silnia_rek(n-1);
	}
}
int fib_rek(int n){
	if( n==0 || n==1){
		return n;
	}
	else{
		return fib_rek(n-1) + fib_rek(n-2);
	}
}
int pot_naturalne_rek(int a, int n){
	if(n==0){
		return 1;
	}
	else{
		return a * pot_naturalne_rek(a,n-1);
	}
}
int main(){
	int n;
	int a;
	cout << "Podaj liczbe dla ktorej chcesz obliczyc silnie" << endl;
	cin>>n;
	cout << "Silnia iteracyjna : " << silnia_iter(n) << endl;
	cout << "Silnia rekurencyjna : " << silnia_rek(n) << endl;
	cout << "Podaj n dla ktorego chcesz obliczyc n wyraz ciagu fib: "<< endl;
	cin>>n;
	cout << "Ciag fib iteracyjny: " << fib_iter(n) << endl;
	cout << "Ciag fib rekurencyjny: " << fib_rek(n) << endl;
	cout << "Podaj liczbe i jej potege: " << endl;
	cin>>a>>n;
	cout << a << " do potegi " << n << " to: " << pot_naturalne_iter(a,n) << " iteracyjnie" << endl;
	cout << a << " do potegi " << n << " to: " << pot_naturalne_rek(a,n) << " rekurencyjnie" << endl;
	return 0;
}
