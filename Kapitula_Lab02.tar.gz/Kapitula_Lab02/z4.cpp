#include <iostream>
using namespace std;
void zamien1(int a,int b){
	int tmp = a;
	a = b;
	b = tmp;
}
void zamien2(int &a, int &b){
	int tmp = a;
	a = b;
	b = tmp;
}
void zamien3(int *a,int *b){
	int tmp = *a;
	*a = *b;
	*b = tmp;
}
int main(){
	int a,b;
	cout << "Podaj dwie liczby" << endl;
	cin>>a>>b;
	cout << "Wartosci przed zamiana a,b : " << a <<"," << b << endl;
	zamien1(a,b);
	cout << "Wartosci po zamianie przez wartosc: " << a << "," << b << endl;
	zamien2(a,b);
	cout << "Wartosc po zamianie przez referencje: " << a << "," << b << endl;
	zamien3(&a,&b);
	cout << "Wartosc po zamianie przez wskaznik: " << a << "," << b << endl;
	return 0;
}
