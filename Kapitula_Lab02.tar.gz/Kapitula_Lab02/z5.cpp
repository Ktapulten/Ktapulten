#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void wypisz(const int* T,const unsigned int N){
	for(unsigned int i=0;i<N;i++){
		cout << T[i] << " ";
	}
	cout << endl;
}

int* utworz1(const unsigned int N){
	return new int[N];
}
void utworz2(int*& T, const unsigned int N){
	T = new int[N];
}
void utworz3(int* T,const unsigned int N){
	for(unsigned int i=0;i<N;i++){
		T[i]=0;
	}
}
void wypelnij(int* T,const unsigned int N){
	srand(time(NULL));
	for(unsigned int i=0;i<N;i++){
		if(i%2==0){
			T[i] = rand() % 21 - 25;
		}
		else{
			T[i] = rand() % 21 + 5;
		}
	}
}
void kasuj(int *T,const unsigned int N,const unsigned int indeks){
	if(indeks<N){
		for(unsigned int i = indeks; i<N-1;i++){
			T[i] = T[i+1];
		}
		T[N-1] = 0;
	}
}

void dodaj(int* T,const unsigned int N, const int wartosc){
	for(unsigned int i=N-1;i>0;i--){
		T[i] = T[i-1];
	}
	T[0]=wartosc;
}
int* suma1(const int* T1,const int* T2,const unsigned int N){
	int* T3 = new int[N];
	for(unsigned int i=0;i<N;i++){
		T3[i] = T1[i] + T2[i];
	}
	return T3;
}
void suma2(const int* T1, const int* T2, int*& T3,const unsigned int N){
	T3 = new int[N];
	for(unsigned int i=0;i<N;++i){
		T3[i] = T1[i] + T2[i];
	}
}
void suma3(const int* T1, const int* T2, int* T3, const unsigned int N){
	for(unsigned int i=0;i<N;++i){
		T3[i] = T1[i] + T2[i];
	}
}
void usun(int*& T){
	if(T!=nullptr){
		delete[] T;
		T = nullptr;
	}
}
void tabliczka_mnozenia(){
	for(int i =1;i<=10;i++){
		for(int j=1;j<=10;++j){
			cout << i*j << " " << endl;
		}
	}
	cout << endl;
	int a,b;
	cout << "Podaj dwie liczby z zakresu <1,10>" << endl;
	cin>>a>>b;
	if(a<1 || a>10 || b<1 || b>10){
		cout << "Iloczyn :" << a*b << endl;
	}
	else{
		cout << "Liczby nie spelniaja warunku <1,10>" << endl;
	}
}
int main(){
	unsigned int N,indeks;
	int wartosc;
	cout << "Podaj liczbe N: " << endl;
	cin>>N;
	cout << "Podaj indeks ktory chcesz skasowac: " << endl;
	cin>>indeks;
	cout << "Podaj wartosc ktora chcesz dodac: " << endl;
	cin>>wartosc;
	return 0;
}
