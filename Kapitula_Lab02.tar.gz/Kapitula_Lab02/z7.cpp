#include <iostream>
#include <cmath>
using namespace std;

float suma(float a, float b){
	return a+b;
}
float roznica(float a,float b){
	return a-b;
}
float iloczyn(float a,float b){
	return a*b;
}
float iloraz(float a,float b){
	if(b == 0){
		cout<<"NIe dzieli sie przez 0"<<endl;
		return 0;
	}
	else{
		return a/b;
	}
}
float kwadrat(float a){
	return a*a;
}
float szescian(float a){
	return a*a*a;
}
float wartosc_wyrazenia(float x){
	return (10*szescian(x)+3.1415*kwadrat(x))*(szescian(x)-1/x);
}
float obwod(float a,float b,float c){
	bool tmp;
	if(a+b>c&&a+c>b&&b+c>a){
		tmp=true;
	}
	else{
		tmp=false;
	}
	if(tmp==true){
		return a+b+c;
	}
	else{
		cout << "Nie mozna zbudowac trojkata z podanymi bokami"<< endl;
		return 0;
	}
}
float pole_trojkata(float a,float b,float c){
	float po =  obwod(a,b,c)/2;
	return sqrt(po*(po-a)*(po-b)*(po-c));
}
void menu(){
	cout << "Opcje: "<<endl;
	cout << "1. Suma "<<endl;
	cout << "2. Roznica "<<endl;
	cout << "3. Iloczyn "<<endl;
	cout << "4. Iloraz "<<endl;
	cout << "5. Kwadrat "<<endl;
	cout << "6. Szescian "<<endl;
	cout << "7. Wartosc wyrazenia "<<endl;
	cout << "8. Obwod trojkata "<<endl;
	cout << "9. Pole trojkata "<<endl;
	cout << "10. Koniec "<<endl;
}
bool kalkulator(){
	int wybor;
	float a,b,c,x;
	menu();
	cin>>wybor;
	switch(wybor){
		case 1:
			cout << "Podaj pierwsza liczbe: ";
			cin>>a;
			cout << "Podaj druga liczbe: ";
			cin>>b;
			cout << "Wynik: " << suma(a,b) << endl;
			break;
		case 2:
			cout << "Podaj pierwsza liczbe: ";
                        cin>>a;
                        cout << "Podaj druga liczbe: ";
                        cin>>b;
                        cout << "Wynik: " << roznica(a,b) << endl;
                        break;
		case 3:
			cout << "Podaj pierwsza liczbe: ";
                        cin>>a;
                        cout << "Podaj druga liczbe: ";
                        cin>>b;
                        cout << "Wynik: " << iloczyn(a,b) << endl;
                        break;
		case 4:
			cout << "Podaj pierwsza liczbe: ";
                        cin>>a;
                        cout << "Podaj druga liczbe: ";
                        cin>>b;
                        cout << "Wynik: " << iloraz(a,b) << endl;
                        break;
		case 5:
			cout << "Podaj liczbe: ";
                        cin>>a;
                        cout << "Wynik: " << kwadrat(a) << endl;
                        break;
		case 6:
			cout << "Podaj pierwsza liczbe: ";
                        cin>>a;
                        cout << "Wynik: " << szescian(a) << endl;
                        break;
		case 7:
			cout << "Podaj x: ";
                        cin>>x;
                        cout << "Wynik: " << wartosc_wyrazenia(x) << endl;
                        break;
		case 8:
			cout << "Podaj dlugosci bokow a,b,c" << endl;
			cin>>a>>b>>c;
			cout << "Wynik: " << obwod(a,b,c) << endl;
			break;
		case 9:
			cout << "Podaj dlugosci bokow a,b,c" << endl;
			cin>>a>>b>>c;
			cout << "Wynik: " << pole_trojkata(a,b,c) << endl;
			break;
		case 10:
			return false;
	}
	return true;
}
int main(){
	while(kalkulator());
	return 0;
}
