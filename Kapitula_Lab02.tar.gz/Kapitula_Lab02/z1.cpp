#include <iostream>
using namespace std;
int potegowanie_binarne(int x,int y){
	int wynik = 1;
	while(y>0){
		if(y%2==1){
			wynik = x;
		}
		wynik *= x;
		y /=2;
	}
	return wynik;
}
int main(){
	int x,y;
	cout << "Podaj liczbe ktora chcesz podniesc do potegi" << endl;
	cin >> x;
	cout << "Podaj do ktorej potegi chcesz podniesc ta liczbe" << endl;
	cin >> y;
	potegowanie_binarne(x,y);
	return 0;
}
