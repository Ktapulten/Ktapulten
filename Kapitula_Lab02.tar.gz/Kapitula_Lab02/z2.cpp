#include <iostream>
using namespace std;

void podziel(int *T,int p_polowa,int d_polowa, int& min, int& max){
	if(p_polowa==d_polowa){
		min = max = T[p_polowa];
	}
	else if(p_polowa + 1 == d_polowa){
		if(T[p_polowa]<T[d_polowa]){
			min = T[p_polowa];
			max = T[d_polowa];
		}
		else{
			min = T[d_polowa];
			max = T[p_polowa];
		}
	}
	else{
		int srodek = (p_polowa + d_polowa)/2;
		int min1,min2,max1,max2;
		podziel(T,p_polowa,srodek,min1,max1);
		podziel(T,srodek + 1,d_polowa,min2,max2);
		min = min1 < min2 ? min1 : min2;
		max = max1 > max2 ? max1 : max2;
	}
}
void wynik(int *T,const unsigned N,int &min,int&max){
	if(N==0){
		min = max = 0;
	}
	else{
		podziel(T,0,N-1,min,max);
	}
}
int main(){
	unsigned int N;
	cout << "Podaj liczbe N" << endl;
	cin >> N;
	int *T = new int[N];
	for(unsigned int i =0;i<N;i++){
		cout << "podaj liczbe ktora ma byc w tablicy na miejscu: " << i << endl;
		cin >> T[i];
	}
	int min,max;
	wynik(T,N,min,max);
	cout << "Najmniejszy element to " << min << endl;
	cout << "Najwiekszy element to " << max << endl;
	delete[] T;
	T=nullptr;
	return 0;
}
