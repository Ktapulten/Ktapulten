#include <iostream>
#include <cstdlib>
using namespace std;
int suma(int a,int b){
	return a+b;
}
int roznica(int a,int b){
	return a-b;
}
int iloczyn(int a,int b){
	return a*b;
}
int iloraz(int a,int b){
	return a/b;
}
bool sprawdz(int (*f)(int,int),int a,int b){
	return f(a,b) >= 0;
}
int main(int argc,char *argv[]){
	if(argc!=3){
		cout << "POdaj dwie liczby jako argumenty programu" << endl;
	}
	//int a = atoi(argv[1]);
	//int b = atoi(argv[2]);
	int a;
	int b;
	cout << "Podaj dwie liczby całkowite: " << endl;
	cin >> a;
	cin >> b;
	if(sprawdz(suma, a, b)){
		cout << "Suma jest wieksza lub rowna 0" << endl;
		cout << suma << endl;}
	else{
		cout << "Suma jest mniejsza od 0" << endl;
		cout << suma << endl;}
	if(sprawdz(roznica, a, b)){
		cout << "Roznica jest wieksza lub rowna 0" << endl;
		cout << roznica  << endl;}
	else{
		cout << "Roznica jest mniejsza od 0" << endl;
		cout << roznica  << endl;}
	if(sprawdz(iloczyn, a, b)){
		cout << "Iloczyn jest wiekszy lub rowna 0" << endl;
		cout << iloczyn << endl;}
	else{
		cout << "Iloczyn jest mniejszy od 0" << endl;
		cout << iloczyn << endl;}
	if(sprawdz(iloraz, a, b)){
		cout << "Iloraz jest wiekszy lub rowna 0" << endl;
		cout << iloraz << endl;}
	else{
		cout << "Iloraz jest mniejszy od 0" << endl;
		cout << iloraz << endl;}
	return 0;
}
