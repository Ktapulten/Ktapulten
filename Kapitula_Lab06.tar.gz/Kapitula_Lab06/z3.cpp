#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool is_email(string str) {
    size_t at_pos = str.find('@');
    return (at_pos != string::npos && at_pos != 0 && at_pos != str.length()-1);
}

void select_emails(string input_file, string output_file) {
    ifstream in(input_file);
    ofstream out(output_file);
    string word;
    while (in >> word) {
        if (is_email(word) && word.find_first_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") != string::npos) {
            out << word << endl;
        }
        else {
            size_t last_pos = 0;
            size_t pos;
            while ((pos = word.find_first_of("; \n", last_pos)) != string::npos) {
                string email = word.substr(last_pos, pos - last_pos);
                if (is_email(email)) {
                    out << email << endl;
                }
                last_pos = pos + 1;
            }
            string email = word.substr(last_pos);
            if (is_email(email)) {
                out << email << endl;
            }
        }
    }
    in.close();
    out.close();
}
