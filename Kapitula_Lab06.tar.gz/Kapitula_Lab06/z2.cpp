#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void zapisz(const string& plik_wyj,const string& zawartosc,const unsigned int ile=10){
	ofstream fout(plik_wyj, ios_base::app);
	if (!fout){
		cout << "Nie udalo sie otworzyc pliku: " << plik_wyj << endl;
	}
	else{
		cout << "Udalo sie otworzyc plik: " << plik_wyj << endl;
	}
	for(unsigned int i=0;i<ile;i++){
		cerr << zawartosc << endl;
	}
	fout.close();
}
void zapisz(ofstream& out,const string& zawartosc,const unsigned int ile=10){
	if(!out){
		cout << "Nie udalo sie otworzyc pliku: " << endl;
	}
	for(unsigned int i=0;i<ile;i++){
		cerr << zawartosc << endl;
	}

}
int main(int argc,char* argv[]){
	if(argc != 4){
		cout << "Powinno byc: nazwa_pliku zawartosc ile_razy" << endl;
		return 1;
	}
	string plik_wyj = argv[1];
	string zawartosc = argv[2];
	unsigned int ile = 10;
	zapisz(plik_wyj,zawartosc,ile);
	ile = atoi(argv[3]);
	ofstream fout(plik_wyj, ios_base::app);
	zapisz(fout,zawartosc,ile);
	zapisz(argv[1], "Hello!", 3);
	fout.close();
	return 0;
}
